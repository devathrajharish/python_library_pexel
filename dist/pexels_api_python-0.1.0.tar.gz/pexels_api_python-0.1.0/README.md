# Pexels API Python

A Python wrapper for the Pexels API, allowing you to search for photos, get photo details, and fetch popular photos.

## Installation

You can install the library using pip:

```bash
pip install pexels_api_python